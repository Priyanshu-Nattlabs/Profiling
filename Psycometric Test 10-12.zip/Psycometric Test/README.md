# Psychometric Testing App

Full-stack starter for the psychometric testing flow: React (Vite + TS) frontend, Spring Boot 3 backend, MongoDB, Docker Compose.

## Quick start

```bash
cp env.example .env
docker compose up --build
```

Frontend: http://localhost:5173  
Backend: http://localhost:8080  
Mongo: mongodb://localhost:27017/psychometric

## Backend (Spring Boot)

- `POST /api/psychometric/sessions` – create session from pre-test form and generate 3×50 placeholder questions (swap with OpenAI).
- `GET /api/psychometric/sessions/{id}` – fetch session with questions and report (report null until generated).

Configure with env vars:
- `MONGODB_URI` (default: `mongodb://mongo:27017/psychometric`)
- `OPENAI_API_KEY` (used when you wire OpenAI calls)

Build locally: `cd backend && gradle bootRun`

## Frontend (React + Vite)

- Route `/psychometric/start` renders the pre-test form, validates input, and calls the backend endpoint.
- Set `VITE_API_BASE_URL` to point at the backend (defaults to `http://localhost:8080`).

Run locally: `cd frontend && npm install && npm run dev`



