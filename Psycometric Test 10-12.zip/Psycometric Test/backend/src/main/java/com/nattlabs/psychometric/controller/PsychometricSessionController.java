package com.nattlabs.psychometric.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nattlabs.psychometric.dto.CreateSessionRequest;
import com.nattlabs.psychometric.dto.CreateSessionResponse;
import com.nattlabs.psychometric.dto.PsychometricSessionResponse;
import com.nattlabs.psychometric.dto.SessionStatusResponse;
import com.nattlabs.psychometric.model.PsychometricSession;
import com.nattlabs.psychometric.model.Question;
import com.nattlabs.psychometric.model.SessionStatus;
import com.nattlabs.psychometric.service.PsychometricSessionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/psychometric/sessions")
@Validated
public class PsychometricSessionController {

    private final PsychometricSessionService sessionService;

    public PsychometricSessionController(PsychometricSessionService sessionService) {
        this.sessionService = sessionService;
    }

    @PostMapping
    public ResponseEntity<CreateSessionResponse> createSession(
            @Valid @RequestBody CreateSessionRequest request) {
        PsychometricSession session = sessionService.createSession(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(new CreateSessionResponse(session.getId()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<PsychometricSessionResponse> getSession(@PathVariable String id) {
        return sessionService.getSession(id)
                .map(PsychometricSessionResponse::from)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/status")
    public ResponseEntity<SessionStatusResponse> getSessionStatus(@PathVariable String id) {
        return sessionService.getSession(id)
                .map(SessionStatusResponse::from)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/questions")
    public ResponseEntity<List<Question>> getSessionQuestions(@PathVariable String id) {
        return sessionService.getSession(id)
                .map(session -> {
                    // Only return questions if session is READY
                    if (session.getStatus() == SessionStatus.READY) {
                        return ResponseEntity.ok(session.getQuestions());
                    } else {
                        return ResponseEntity.status(HttpStatus.ACCEPTED).body(session.getQuestions());
                    }
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}


