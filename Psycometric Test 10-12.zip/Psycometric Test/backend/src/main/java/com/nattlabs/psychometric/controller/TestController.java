package com.nattlabs.psychometric.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nattlabs.psychometric.dto.CheatEventRequest;
import com.nattlabs.psychometric.dto.SubmitTestRequest;
import com.nattlabs.psychometric.dto.SubmitTestResponse;
import com.nattlabs.psychometric.service.PsychometricSessionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/test")
@Validated
public class TestController {

    private final PsychometricSessionService sessionService;

    public TestController(PsychometricSessionService sessionService) {
        this.sessionService = sessionService;
    }

    @PostMapping("/submit")
    public ResponseEntity<SubmitTestResponse> submitTest(
            @Valid @RequestBody SubmitTestRequest request) {
        SubmitTestResponse response = sessionService.submitTest(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/log-cheat-event")
    public ResponseEntity<Void> logCheatEvent(
            @Valid @RequestBody CheatEventRequest request) {
        sessionService.logCheatEvent(request);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}

