package com.nattlabs.psychometric.dto;

import com.nattlabs.psychometric.model.UserInfo;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class CreateSessionRequest {

    @Valid
    @NotNull
    private UserInfo userInfo;

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }
   
}



