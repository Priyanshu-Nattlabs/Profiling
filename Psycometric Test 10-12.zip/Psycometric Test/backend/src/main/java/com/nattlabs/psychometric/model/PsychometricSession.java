package com.nattlabs.psychometric.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@Document(collection = "psychometric_sessions")
public class PsychometricSession {

    @Id
    private String id;

    @NotNull
    @Valid
    private UserInfo userInfo;

    private SessionStatus status = SessionStatus.CREATED;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    private List<Question> questions = new ArrayList<>();
    private List<Answer> answers = new ArrayList<>();
    private Report report;

    // Progress tracking for async generation
    private boolean aptitudeReady = false;
    private boolean behavioralReady = false;
    private boolean domainReady = false;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public SessionStatus getStatus() {
        return status;
    }

    public void setStatus(SessionStatus status) {
        this.status = status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public void setAnswers(List<Answer> answers) {
        this.answers = answers;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    public boolean isAptitudeReady() {
        return aptitudeReady;
    }

    public void setAptitudeReady(boolean aptitudeReady) {
        this.aptitudeReady = aptitudeReady;
    }

    public boolean isBehavioralReady() {
        return behavioralReady;
    }

    public void setBehavioralReady(boolean behavioralReady) {
        this.behavioralReady = behavioralReady;
    }

    public boolean isDomainReady() {
        return domainReady;
    }

    public void setDomainReady(boolean domainReady) {
        this.domainReady = domainReady;
    }
}

