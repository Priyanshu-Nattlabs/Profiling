package com.nattlabs.psychometric.model;

public enum SessionStatus {
    CREATED,
    GENERATING,
    READY,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}


