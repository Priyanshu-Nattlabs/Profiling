package com.nattlabs.psychometric.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.nattlabs.psychometric.model.PsychometricSession;

@Repository
public interface PsychometricSessionRepository extends MongoRepository<PsychometricSession, String> {
}



