package com.nattlabs.psychometric.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nattlabs.psychometric.dto.CheatEventRequest;
import com.nattlabs.psychometric.dto.CreateSessionRequest;
import com.nattlabs.psychometric.dto.SubmitTestRequest;
import com.nattlabs.psychometric.dto.SubmitTestResponse;
import com.nattlabs.psychometric.model.PsychometricSession;
import com.nattlabs.psychometric.model.SessionStatus;
import com.nattlabs.psychometric.model.UserInfo;
import com.nattlabs.psychometric.repository.PsychometricSessionRepository;

@Service
public class PsychometricSessionService {

    private final PsychometricSessionRepository repository;
    private final PsychometricAsyncService asyncService;

    public PsychometricSessionService(
            PsychometricSessionRepository repository,
            PsychometricAsyncService asyncService) {
        this.repository = repository;
        this.asyncService = asyncService;
    }

    @Transactional
    public PsychometricSession createSession(CreateSessionRequest request) {
        PsychometricSession session = new PsychometricSession();
        session.setUserInfo(request.getUserInfo());
        session.setStatus(SessionStatus.CREATED);
        // Save session first without questions
        PsychometricSession savedSession = repository.save(session);
        
        // Update status to GENERATING before starting async tasks
        savedSession.setStatus(SessionStatus.GENERATING);
        repository.save(savedSession);
        
        // Start three async tasks for generating questions
        UserInfo userInfo = request.getUserInfo();
        asyncService.generateSection1Questions(savedSession.getId(), userInfo);
        asyncService.generateSection2Questions(savedSession.getId(), userInfo);
        asyncService.generateSection3Questions(savedSession.getId(), userInfo);
        
        return savedSession;
    }

    public Optional<PsychometricSession> getSession(String id) {
        return repository.findById(id);
    }

    public List<com.nattlabs.psychometric.model.Question> getQuestions(String sessionId) {
        return repository.findById(sessionId)
                .map(PsychometricSession::getQuestions)
                .orElse(java.util.Collections.emptyList());
    }

    @Transactional
    public SubmitTestResponse submitTest(SubmitTestRequest request) {
        Optional<PsychometricSession> sessionOpt = repository.findById(request.getSessionId());
        
        if (sessionOpt.isEmpty()) {
            throw new IllegalArgumentException("Session not found: " + request.getSessionId());
        }

        PsychometricSession session = sessionOpt.get();
        
        // Store answers
        session.setAnswers(request.getAnswers());
        
        // Update session status to COMPLETED
        session.setStatus(SessionStatus.COMPLETED);
        
        // Save the session
        repository.save(session);

        // Parse submittedAt from ISO string to Instant
        Instant submittedAt = Instant.parse(request.getResults().getSubmittedAt());

        // Create and return response
        SubmitTestResponse response = new SubmitTestResponse(
            request.getSessionId(),
            request.getUserId(),
            request.getTestId(),
            request.getResults().getTotalQuestions(),
            request.getResults().getAttempted(),
            request.getResults().getNotAttempted(),
            request.getResults().getCorrect(),
            request.getResults().getWrong(),
            request.getResults().getMarkedForReview(),
            request.getResults().getAnsweredAndMarkedForReview(),
            request.getWarnings(),
            request.getSubmittedBy(),
            submittedAt
        );

        return response;
    }

    public void logCheatEvent(CheatEventRequest request) {
        // Log cheat event - in production, you might want to store this in a separate collection
        System.out.println(String.format(
            "Cheat Event Logged - Session: %s, Reason: %s, Warning Count: %d, Timestamp: %s",
            request.getSessionId(),
            request.getReason(),
            request.getWarningCount(),
            request.getTimestamp()
        ));
        // TODO: Store in database or logging service
    }
}

