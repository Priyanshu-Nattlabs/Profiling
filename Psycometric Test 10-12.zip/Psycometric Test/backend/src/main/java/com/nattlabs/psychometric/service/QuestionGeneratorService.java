package com.nattlabs.psychometric.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nattlabs.psychometric.dto.OpenAIRequest;
import com.nattlabs.psychometric.dto.OpenAIResponse;
import com.nattlabs.psychometric.model.Question;
import com.nattlabs.psychometric.model.UserInfo;

import reactor.core.publisher.Mono;

@Service
public class QuestionGeneratorService {

    private final WebClient.Builder webClientBuilder;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${openai.apiKey:}")
    private String openAiApiKey;

    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
    private static final int QUESTIONS_PER_BATCH = 10;

    public QuestionGeneratorService(WebClient.Builder webClientBuilder) {
        this.webClientBuilder = webClientBuilder;
    }

    /**
     * Generates 150 questions (50 per section) using OpenAI API.
     */
    public List<Question> generateQuestions(UserInfo userInfo) {
        List<Question> questions = new ArrayList<>();
        
        if (openAiApiKey == null || openAiApiKey.isEmpty()) {
            // Fallback to placeholder if API key is not configured
            questions.addAll(buildAptitudeSectionPlaceholder());
            questions.addAll(buildPersonalitySectionPlaceholder());
            questions.addAll(buildDomainSectionPlaceholder(userInfo));
            return questions;
        }

        try {
            questions.addAll(buildAptitudeSection(userInfo));
            questions.addAll(buildPersonalitySection(userInfo));
            questions.addAll(buildDomainSection(userInfo));
        } catch (Exception e) {
            // Fallback to placeholders on error
            System.err.println("Error generating questions with OpenAI: " + e.getMessage());
            e.printStackTrace();
            questions.clear();
            questions.addAll(buildAptitudeSectionPlaceholder());
            questions.addAll(buildPersonalitySectionPlaceholder());
            questions.addAll(buildDomainSectionPlaceholder(userInfo));
        }
        
        return questions;
    }

    /**
     * Generates 50 aptitude questions (Section 1) independently.
     */
    public List<Question> generateSection1Questions(UserInfo userInfo) {
        if (openAiApiKey == null || openAiApiKey.isEmpty()) {
            return buildAptitudeSectionPlaceholder();
        }
        try {
            return buildAptitudeSection(userInfo);
        } catch (Exception e) {
            System.err.println("Error generating section 1 questions with OpenAI: " + e.getMessage());
            e.printStackTrace();
            return buildAptitudeSectionPlaceholder();
        }
    }

    /**
     * Generates 50 behavioral/personality questions (Section 2) independently.
     */
    public List<Question> generateSection2Questions(UserInfo userInfo) {
        if (openAiApiKey == null || openAiApiKey.isEmpty()) {
            return buildPersonalitySectionPlaceholder();
        }
        try {
            return buildPersonalitySection(userInfo);
        } catch (Exception e) {
            System.err.println("Error generating section 2 questions with OpenAI: " + e.getMessage());
            e.printStackTrace();
            return buildPersonalitySectionPlaceholder();
        }
    }

    /**
     * Generates 50 domain-specific questions (Section 3) independently.
     */
    public List<Question> generateSection3Questions(UserInfo userInfo) {
        if (openAiApiKey == null || openAiApiKey.isEmpty()) {
            return buildDomainSectionPlaceholder(userInfo);
        }
        try {
            return buildDomainSection(userInfo);
        } catch (Exception e) {
            System.err.println("Error generating section 3 questions with OpenAI: " + e.getMessage());
            e.printStackTrace();
            return buildDomainSectionPlaceholder(userInfo);
        }
    }

    private List<Question> buildAptitudeSection(UserInfo userInfo) {
        List<String> categories = Arrays.asList(
                "numerical", "verbal", "situational", "diagrammatic", "abstract", "logical");
        return generateSectionQuestionsWithOpenAI(1, categories, "MCQ", userInfo);
    }

    private List<Question> buildPersonalitySection(UserInfo userInfo) {
        List<String> categories = Arrays.asList(
                "conflict_resolution",
                "attention_to_detail",
                "leadership",
                "adaptability",
                "big_five_openness",
                "big_five_conscientiousness",
                "big_five_extraversion",
                "big_five_agreeableness",
                "big_five_neuroticism");
        return generateSectionQuestionsWithOpenAI(2, categories, "LIKERT", userInfo);
    }

    private List<Question> buildDomainSection(UserInfo userInfo) {
        String degree = userInfo.getDegree().toLowerCase();
        List<String> categories = new ArrayList<>();
        if (degree.contains("b.tech") || degree.contains("btech") || degree.contains("cs") || degree.contains("it")) {
            categories = Arrays.asList("technical_reasoning", "debugging", "systems_thinking", "problem_solving");
        } else if (degree.contains("bba")) {
            categories = Arrays.asList("business_reasoning", "management", "marketing", "operations");
        } else if (degree.contains("b.com") || degree.contains("bcom")) {
            categories = Arrays.asList("finance", "accounting", "commercial_awareness");
        } else if (degree.contains("mba")) {
            categories = Arrays.asList("management_case", "decision_making", "strategy");
        } else {
            categories = Arrays.asList("career_reasoning", "general_problem_solving", "situational");
        }
        return generateSectionQuestionsWithOpenAI(3, categories, "SCENARIO", userInfo);
    }

    // Placeholder methods for fallback
    private List<Question> buildAptitudeSectionPlaceholder() {
        List<String> categories = Arrays.asList(
                "numerical", "verbal", "situational", "diagrammatic", "abstract", "logical");
        return generateSectionQuestionsPlaceholder(1, categories, "MCQ");
    }

    private List<Question> buildPersonalitySectionPlaceholder() {
        List<String> categories = Arrays.asList(
                "conflict_resolution",
                "attention_to_detail",
                "leadership",
                "adaptability",
                "big_five_openness",
                "big_five_conscientiousness",
                "big_five_extraversion",
                "big_five_agreeableness",
                "big_five_neuroticism");
        return generateSectionQuestionsPlaceholder(2, categories, "LIKERT");
    }

    private List<Question> buildDomainSectionPlaceholder(UserInfo userInfo) {
        String degree = userInfo.getDegree().toLowerCase();
        List<String> categories = new ArrayList<>();
        if (degree.contains("b.tech") || degree.contains("btech") || degree.contains("cs") || degree.contains("it")) {
            categories = Arrays.asList("technical_reasoning", "debugging", "systems_thinking", "problem_solving");
        } else if (degree.contains("bba")) {
            categories = Arrays.asList("business_reasoning", "management", "marketing", "operations");
        } else if (degree.contains("b.com") || degree.contains("bcom")) {
            categories = Arrays.asList("finance", "accounting", "commercial_awareness");
        } else if (degree.contains("mba")) {
            categories = Arrays.asList("management_case", "decision_making", "strategy");
        } else {
            categories = Arrays.asList("career_reasoning", "general_problem_solving", "situational");
        }
        return generateSectionQuestionsPlaceholder(3, categories, "SCENARIO");
    }

    private List<Question> generateSectionQuestionsWithOpenAI(int sectionNumber, List<String> categories, 
                                                               String questionType, UserInfo userInfo) {
        List<Question> results = new ArrayList<>();
        int total = 50;
        
        // Generate questions in batches
        for (int batchStart = 0; batchStart < total; batchStart += QUESTIONS_PER_BATCH) {
            int batchSize = Math.min(QUESTIONS_PER_BATCH, total - batchStart);
            List<String> batchCategories = new ArrayList<>();
            for (int i = 0; i < batchSize; i++) {
                batchCategories.add(categories.get((batchStart + i) % categories.size()));
            }
            
            List<Question> batchQuestions = generateBatchWithOpenAI(
                sectionNumber, batchCategories, questionType, batchStart + 1, userInfo);
            results.addAll(batchQuestions);
        }
        
        return results;
    }

    private List<Question> generateBatchWithOpenAI(int sectionNumber, List<String> categories, 
                                                    String questionType, int startIndex, UserInfo userInfo) {
        try {
            String prompt = buildPromptForBatch(sectionNumber, categories, questionType, startIndex, userInfo);
            OpenAIRequest request = new OpenAIRequest(prompt);
            
            WebClient webClient = webClientBuilder
                .baseUrl(OPENAI_API_URL)
                .defaultHeader("Authorization", "Bearer " + openAiApiKey)
                .defaultHeader("Content-Type", "application/json")
                .build();
            
            OpenAIResponse response = webClient.post()
                .bodyValue(request)
                .retrieve()
                .bodyToMono(OpenAIResponse.class)
                .block();
            
            if (response != null && response.getChoices() != null && !response.getChoices().isEmpty()) {
                String content = response.getChoices().get(0).getMessage().getContent();
                return parseQuestionsFromResponse(content, sectionNumber, categories, questionType, startIndex);
            }
        } catch (Exception e) {
            System.err.println("Error calling OpenAI API: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Fallback to placeholder on error
        return generateSectionQuestionsPlaceholderBatch(sectionNumber, categories, questionType, startIndex);
    }

    private String buildPromptForBatch(int sectionNumber, List<String> categories, String questionType, 
                                       int startIndex, UserInfo userInfo) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("You are a psychometric assessment question generator. Generate ")
              .append(categories.size())
              .append(" high-quality questions for a psychometric test.\n\n");
        
        if (sectionNumber == 1) {
            prompt.append("Section: Aptitude & Cognitive Assessment\n");
            prompt.append("Question Type: Multiple Choice (MCQ)\n");
        } else if (sectionNumber == 2) {
            prompt.append("Section: Personality Assessment\n");
            prompt.append("Question Type: Likert Scale\n");
        } else {
            prompt.append("Section: Domain-Specific Assessment\n");
            prompt.append("User Degree: ").append(userInfo.getDegree()).append("\n");
            prompt.append("User Specialization: ").append(userInfo.getSpecialization()).append("\n");
            prompt.append("Career Interest: ").append(userInfo.getCareerInterest()).append("\n");
            prompt.append("Question Type: Scenario-based\n");
        }
        
        prompt.append("\nCategories for this batch:\n");
        for (int i = 0; i < categories.size(); i++) {
            prompt.append((i + 1)).append(". ").append(categories.get(i)).append("\n");
        }
        
        prompt.append("\nGenerate exactly ").append(categories.size()).append(" questions, one for each category.\n");
        prompt.append("Return ONLY a valid JSON array with no additional text or markdown. Each question should be an object with this exact format:\n");
        prompt.append("[\n");
        prompt.append("  {\n");
        prompt.append("    \"prompt\": \"The actual question text here\",\n");
        if ("LIKERT".equals(questionType)) {
            prompt.append("    \"options\": [\"Strongly disagree\", \"Disagree\", \"Neutral\", \"Agree\", \"Strongly agree\"]\n");
        } else {
            prompt.append("    \"options\": [\"First option text\", \"Second option text\", \"Third option text\", \"Fourth option text\"]\n");
        }
        prompt.append("  },\n");
        prompt.append("  ... (repeat for each question)\n");
        prompt.append("]\n\n");
        prompt.append("IMPORTANT: Return ONLY the JSON array, no explanations, no markdown code blocks, just pure JSON. ");
        prompt.append("Make each question relevant, realistic, professional, and appropriate for psychometric assessment. ");
        prompt.append("Ensure all questions are suitable for someone with degree: ").append(userInfo.getDegree())
               .append(", specialization: ").append(userInfo.getSpecialization()).append(".");
        
        return prompt.toString();
    }

    private List<Question> parseQuestionsFromResponse(String content, int sectionNumber, 
                                                       List<String> categories, String questionType, int startIndex) {
        List<Question> questions = new ArrayList<>();
        
        try {
            // Try to extract JSON array from the response
            String jsonContent = extractJsonArray(content);
            ObjectMapper mapper = new ObjectMapper();
            
            @SuppressWarnings("unchecked")
            List<java.util.Map<String, Object>> questionList = mapper.readValue(jsonContent, List.class);
            
            for (int i = 0; i < questionList.size() && i < categories.size(); i++) {
                java.util.Map<String, Object> qData = questionList.get(i);
                Question question = new Question();
                question.setId(UUID.randomUUID().toString());
                question.setSectionNumber(sectionNumber);
                question.setCategory(categories.get(i));
                question.setQuestionType(questionType);
                question.setPrompt((String) qData.get("prompt"));
                
                @SuppressWarnings("unchecked")
                List<String> options = (List<String>) qData.get("options");
                if (options != null) {
                    question.setOptions(options);
                } else {
                    question.setOptions(defaultOptions(questionType));
                }
                
                question.setCorrectOptionIndex("MCQ".equals(questionType) ? 0 : null);
                questions.add(question);
            }
        } catch (Exception e) {
            System.err.println("Error parsing OpenAI response: " + e.getMessage());
            // Fallback to placeholder
            return generateSectionQuestionsPlaceholderBatch(sectionNumber, categories, questionType, startIndex);
        }
        
        return questions;
    }

    private String extractJsonArray(String content) {
        // Remove markdown code blocks if present
        content = content.trim();
        if (content.startsWith("```json")) {
            content = content.substring(7);
        } else if (content.startsWith("```")) {
            content = content.substring(3);
        }
        if (content.endsWith("```")) {
            content = content.substring(0, content.length() - 3);
        }
        content = content.trim();
        
        // Try to find JSON array in the response
        Pattern pattern = Pattern.compile("\\[.*\\]", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            return matcher.group();
        }
        return content;
    }

    private List<Question> generateSectionQuestionsPlaceholder(int sectionNumber, List<String> categories, String questionType) {
        List<Question> results = new ArrayList<>();
        int total = 50;
        for (int i = 0; i < total; i++) {
            String category = categories.get(i % categories.size());
            Question question = new Question();
            question.setId(UUID.randomUUID().toString());
            question.setSectionNumber(sectionNumber);
            question.setCategory(category);
            question.setQuestionType(questionType);
            question.setPrompt("Placeholder prompt for " + category + " question " + (i + 1) + " in section "
                    + sectionNumber + ". Replace with OpenAI generated text.");
            question.setOptions(defaultOptions(questionType));
            question.setCorrectOptionIndex("MCQ".equals(questionType) ? 0 : null);
            results.add(question);
        }
        return results;
    }

    private List<Question> generateSectionQuestionsPlaceholderBatch(int sectionNumber, List<String> categories, 
                                                                     String questionType, int startIndex) {
        List<Question> results = new ArrayList<>();
        for (int i = 0; i < categories.size(); i++) {
            String category = categories.get(i);
            Question question = new Question();
            question.setId(UUID.randomUUID().toString());
            question.setSectionNumber(sectionNumber);
            question.setCategory(category);
            question.setQuestionType(questionType);
            question.setPrompt("Placeholder prompt for " + category + " question " + (startIndex + i) + " in section "
                    + sectionNumber + ". Replace with OpenAI generated text.");
            question.setOptions(defaultOptions(questionType));
            question.setCorrectOptionIndex("MCQ".equals(questionType) ? 0 : null);
            results.add(question);
        }
        return results;
    }

    private List<String> defaultOptions(String questionType) {
        if ("LIKERT".equals(questionType)) {
            return Arrays.asList("Strongly disagree", "Disagree", "Neutral", "Agree", "Strongly agree");
        }
        return Arrays.asList("Option A", "Option B", "Option C", "Option D");
    }
}

