import { Routes, Route, Navigate } from 'react-router-dom'
import PsychometricStart from './pages/PsychometricStart'
import PsychometricInstructions from './pages/PsychometricInstructions'
import PsychometricAssessment from './pages/PsychometricAssessment'
import PsychometricResult from './pages/PsychometricResult'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/psychometric/start" replace />} />
      <Route path="/psychometric/start" element={<PsychometricStart />} />
      <Route path="/psychometric/instructions/:sessionId" element={<PsychometricInstructions />} />
      <Route path="/psychometric/assessment/:sessionId" element={<PsychometricAssessment />} />
      <Route path="/psychometric/result/:sessionId" element={<PsychometricResult />} />
      <Route path="*" element={<Navigate to="/psychometric/start" replace />} />
    </Routes>
  )
}

export default App

