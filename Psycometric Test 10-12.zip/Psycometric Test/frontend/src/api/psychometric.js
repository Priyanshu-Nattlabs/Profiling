const baseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080'

export async function createPsychometricSession(userInfo) {
  try {
    const response = await fetch(`${baseUrl}/api/psychometric/sessions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userInfo }),
    })

    if (!response.ok) {
      let message = 'Unable to start session'
      try {
        const errorBody = await response.json()
        message =
          typeof errorBody === 'string'
            ? errorBody
            : JSON.stringify(errorBody)
      } catch (err) {
        // ignore parsing errors and use default message
        message = `Server error: ${response.status} ${response.statusText}`
      }
      throw new Error(message)
    }

    return response.json()
  } catch (error) {
    // Handle network errors, CORS issues, etc.
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error(
        `Failed to connect to backend at ${baseUrl}. Please ensure the backend is running and accessible.`
      )
    }
    throw error
  }
}

export async function getPsychometricSession(sessionId) {
  try {
    const response = await fetch(`${baseUrl}/api/psychometric/sessions/${sessionId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      let message = 'Unable to fetch session'
      try {
        const errorBody = await response.json()
        message =
          typeof errorBody === 'string'
            ? errorBody
            : JSON.stringify(errorBody)
      } catch (err) {
        message = `Server error: ${response.status} ${response.statusText}`
      }
      throw new Error(message)
    }

    return response.json()
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error(
        `Failed to connect to backend at ${baseUrl}. Please ensure the backend is running and accessible.`
      )
    }
    throw error
  }
}

export async function getSessionStatus(sessionId) {
  try {
    const response = await fetch(`${baseUrl}/api/psychometric/sessions/${sessionId}/status`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      let message = 'Unable to fetch session status'
      try {
        const errorBody = await response.json()
        message =
          typeof errorBody === 'string'
            ? errorBody
            : JSON.stringify(errorBody)
      } catch (err) {
        message = `Server error: ${response.status} ${response.statusText}`
      }
      throw new Error(message)
    }

    return response.json()
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error(
        `Failed to connect to backend at ${baseUrl}. Please ensure the backend is running and accessible.`
      )
    }
    throw error
  }
}

export async function getSessionQuestions(sessionId) {
  try {
    const response = await fetch(`${baseUrl}/api/psychometric/sessions/${sessionId}/questions`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      let message = 'Unable to fetch questions'
      try {
        const errorBody = await response.json()
        message =
          typeof errorBody === 'string'
            ? errorBody
            : JSON.stringify(errorBody)
      } catch (err) {
        message = `Server error: ${response.status} ${response.statusText}`
      }
      throw new Error(message)
    }

    return response.json()
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error(
        `Failed to connect to backend at ${baseUrl}. Please ensure the backend is running and accessible.`
      )
    }
    throw error
  }
}

export async function submitTest(sessionId, submissionData) {
  try {
    const response = await fetch(`${baseUrl}/api/test/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sessionId,
        ...submissionData,
      }),
    })

    if (!response.ok) {
      let message = 'Unable to submit test'
      try {
        const errorBody = await response.json()
        message =
          typeof errorBody === 'string'
            ? errorBody
            : JSON.stringify(errorBody)
      } catch (err) {
        message = `Server error: ${response.status} ${response.statusText}`
      }
      throw new Error(message)
    }

    return response.json()
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error(
        `Failed to connect to backend at ${baseUrl}. Please ensure the backend is running and accessible.`
      )
    }
    throw error
  }
}

