import { QuestionStatus, QuestionStatusColors, QuestionStatusLabels } from '../constants/questionStatus'

function LegendItem({ status }) {
  const isMarkedForReview =
    status === QuestionStatus.MARKED_FOR_REVIEW ||
    status === QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW
  const isAnsweredAndMarked = status === QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW

  return (
    <div className="legend-item">
      <div
        className="legend-box"
        style={{
          width: '24px',
          height: '24px',
          borderRadius: isMarkedForReview ? '50%' : '4px',
          backgroundColor: QuestionStatusColors[status] || '#ffffff',
          border: isAnsweredAndMarked ? '2px solid #4caf50' : '1px solid #d0d5dd',
          flexShrink: 0,
        }}
      />
      <span className="legend-label">{QuestionStatusLabels[status]}</span>
    </div>
  )
}

export default LegendItem

