function MarkForReviewButton({ onClick, isMarked }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`btn-mark-review ${isMarked ? 'marked' : ''}`}
    >
      {isMarked ? 'Unmark for Review' : 'Mark for Review'}
    </button>
  )
}

export default MarkForReviewButton

