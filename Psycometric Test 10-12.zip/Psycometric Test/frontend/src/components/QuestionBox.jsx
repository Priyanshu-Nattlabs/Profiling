import { QuestionStatus, QuestionStatusColors } from '../constants/questionStatus'

function QuestionBox({ questionNumber, status, isCurrent, onClick }) {
  const isMarkedForReview =
    status === QuestionStatus.MARKED_FOR_REVIEW ||
    status === QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW
  const isAnsweredAndMarked =
    status === QuestionStatus.ANSWERED_AND_MARKED_FOR_REVIEW

  // Determine border style - priority: answered+marked > current > default
  let borderStyle = '1px solid #d0d5dd'
  if (isAnsweredAndMarked) {
    borderStyle = '2px solid #4caf50' // Green border for answered+marked (JEE Mains style)
  } else if (isCurrent) {
    borderStyle = '2px solid #2563eb' // Blue border for current question
  }

  const baseStyle = {
    width: '40px',
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    border: borderStyle,
    borderRadius: isMarkedForReview ? '50%' : '8px',
    backgroundColor: QuestionStatusColors[status] || '#ffffff',
    color: status === QuestionStatus.NOT_VISITED ? '#1f2937' : '#ffffff',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '600',
    transition: 'all 0.2s ease',
    position: 'relative',
  }

  // Box shadow for current question indicator
  if (isCurrent && !isAnsweredAndMarked) {
    baseStyle.boxShadow = '0 0 0 3px rgba(37, 99, 235, 0.3)'
  } else if (isCurrent && isAnsweredAndMarked) {
    // For answered+marked current question, use green shadow to match border
    baseStyle.boxShadow = '0 0 0 3px rgba(76, 175, 80, 0.3)'
  }

  return (
    <div
      className="question-box"
      style={baseStyle}
      onClick={onClick}
      onMouseEnter={(e) => {
        if (!isCurrent) {
          e.currentTarget.style.transform = 'scale(1.1)'
          e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.15)'
        }
      }}
      onMouseLeave={(e) => {
        if (!isCurrent) {
          e.currentTarget.style.transform = 'scale(1)'
          e.currentTarget.style.boxShadow = 'none'
        }
      }}
    >
      {questionNumber}
    </div>
  )
}

export default QuestionBox

