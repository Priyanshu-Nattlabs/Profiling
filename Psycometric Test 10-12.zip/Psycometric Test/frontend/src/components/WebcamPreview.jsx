function WebcamPreview({ videoRef, isProctoring, webcamError }) {
  if (webcamError) {
    return (
      <div className="webcam-preview webcam-error">
        <div className="webcam-error-icon">📹</div>
        <div className="webcam-error-text">Webcam unavailable</div>
      </div>
    )
  }

  return (
    <div className="webcam-preview">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="webcam-video"
      />
      {!isProctoring && (
        <div className="webcam-overlay">
          <div className="webcam-status">Proctoring inactive</div>
        </div>
      )}
    </div>
  )
}

export default WebcamPreview

