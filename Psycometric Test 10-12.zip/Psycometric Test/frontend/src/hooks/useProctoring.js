import { useState, useEffect, useRef, useCallback } from 'react'

const MAX_WARNINGS = 5
const FACE_DETECTION_INTERVAL = 2000 // Check every 2 seconds
const LOOK_AWAY_THRESHOLD = 10000 // 10 seconds of no face = looking away

export function useProctoring(sessionId, onMaxWarnings) {
  const [warnings, setWarnings] = useState(0)
  const [isProctoring, setIsProctoring] = useState(false)
  const [webcamError, setWebcamError] = useState(null)
  const [lastWarning, setLastWarning] = useState(null)
  
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const detectionIntervalRef = useRef(null)
  const lastFaceDetectedRef = useRef(Date.now())
  const tabHiddenRef = useRef(false)
  const windowBlurredRef = useRef(false)

  // Load warnings from localStorage
  useEffect(() => {
    if (sessionId) {
      const saved = localStorage.getItem(`proctoring_${sessionId}`)
      if (saved) {
        try {
          const { warnings: savedWarnings } = JSON.parse(saved)
          setWarnings(Math.min(savedWarnings || 0, MAX_WARNINGS))
        } catch (e) {
          console.error('Failed to load proctoring state:', e)
        }
      }
    }
  }, [sessionId])

  // Save warnings to localStorage
  useEffect(() => {
    if (sessionId) {
      localStorage.setItem(
        `proctoring_${sessionId}`,
        JSON.stringify({ warnings })
      )
    }
  }, [sessionId, warnings])

  // Check for max warnings
  useEffect(() => {
    if (warnings >= MAX_WARNINGS && onMaxWarnings) {
      // Use setTimeout to avoid calling during render
      setTimeout(() => {
        onMaxWarnings()
      }, 100)
    }
  }, [warnings, onMaxWarnings])

  // Add warning and log to backend
  const addWarning = useCallback((reason) => {
    setWarnings((prev) => {
      const newWarnings = Math.min(prev + 1, MAX_WARNINGS)
      setLastWarning({ reason, count: newWarnings, timestamp: new Date().toISOString() })
      
      // Log to backend
      logCheatEvent(sessionId, reason, newWarnings)
      
      return newWarnings
    })
  }, [sessionId])

  // Log cheat event to backend
  const logCheatEvent = useCallback(async (sessionId, reason, warningCount) => {
    try {
      const baseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080'
      await fetch(`${baseUrl}/api/test/log-cheat-event`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionId,
          reason,
          warningCount,
          timestamp: new Date().toISOString(),
        }),
      })
    } catch (error) {
      console.error('Failed to log cheat event:', error)
    }
  }, [])

  // Detect tab switching
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (!tabHiddenRef.current) {
          tabHiddenRef.current = true
          addWarning('Tab switched or window minimized')
        }
      } else {
        tabHiddenRef.current = false
      }
    }

    const handleBlur = () => {
      if (!windowBlurredRef.current) {
        windowBlurredRef.current = true
        addWarning('Window lost focus')
      }
    }

    const handleFocus = () => {
      windowBlurredRef.current = false
    }

    document.addEventListener('visibilitychange', handleVisibilityChange)
    window.addEventListener('blur', handleBlur)
    window.addEventListener('focus', handleFocus)

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      window.removeEventListener('blur', handleBlur)
      window.removeEventListener('focus', handleFocus)
    }
  }, [addWarning])

  // Basic face detection using canvas analysis
  const detectFace = useCallback(() => {
    if (!videoRef.current || !streamRef.current) return false

    const video = videoRef.current
    if (video.readyState !== video.HAVE_ENOUGH_DATA) return false

    // Simple heuristic: check if video is playing and has content
    // In a real implementation, you'd use face-api.js or similar
    // For now, we'll use a simplified check
    try {
      const canvas = document.createElement('canvas')
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      const ctx = canvas.getContext('2d')
      ctx.drawImage(video, 0, 0)
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
      const data = imageData.data
      
      // Simple check: if video has significant content (not black/static)
      let hasContent = false
      let sampleCount = 0
      for (let i = 0; i < data.length; i += 16) {
        const r = data[i]
        const g = data[i + 1]
        const b = data[i + 2]
        const brightness = (r + g + b) / 3
        if (brightness > 10 && brightness < 250) {
          hasContent = true
          sampleCount++
        }
      }
      
      // This is a simplified check - in production, use proper face detection
      return hasContent && sampleCount > 100
    } catch (e) {
      console.error('Face detection error:', e)
      return false
    }
  }, [])

  // Start proctoring
  const startProctoring = useCallback(async () => {
    if (isProctoring) return

    try {
      setWebcamError(null)
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
        },
        audio: false,
      })

      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }

      setIsProctoring(true)
      lastFaceDetectedRef.current = Date.now()

      // Start face detection interval
      detectionIntervalRef.current = setInterval(() => {
        const faceDetected = detectFace()
        const now = Date.now()
        
        if (faceDetected) {
          lastFaceDetectedRef.current = now
        } else {
          const timeSinceLastFace = now - lastFaceDetectedRef.current
          if (timeSinceLastFace > LOOK_AWAY_THRESHOLD) {
            addWarning('Face not detected or looking away')
            lastFaceDetectedRef.current = now // Reset to prevent spam
          }
        }

        // Check for video stream failure
        if (videoRef.current && (videoRef.current.readyState === 0 || stream.ended)) {
          addWarning('Video stream interrupted')
        }
      }, FACE_DETECTION_INTERVAL)
    } catch (error) {
      console.error('Failed to start webcam:', error)
      setWebcamError(error.message)
      addWarning('Webcam access denied or unavailable')
    }
  }, [isProctoring, detectFace, addWarning])

  // Stop proctoring
  const stopProctoring = useCallback(() => {
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current)
      detectionIntervalRef.current = null
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setIsProctoring(false)
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopProctoring()
    }
  }, [stopProctoring])

  return {
    warnings,
    isProctoring,
    webcamError,
    lastWarning,
    videoRef,
    startProctoring,
    stopProctoring,
    addWarning,
  }
}

