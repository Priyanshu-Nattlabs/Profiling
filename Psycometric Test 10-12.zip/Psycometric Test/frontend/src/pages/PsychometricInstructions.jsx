import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { getSessionStatus, getSessionQuestions } from '../api/psychometric'

const EXPECTED_QUESTION_COUNT = 150
const POLL_INTERVAL_MS = 3000

function PsychometricInstructions() {
  const { sessionId } = useParams()
  const navigate = useNavigate()

  const [isPreparing, setIsPreparing] = useState(true)
  const [questionsReady, setQuestionsReady] = useState(false)
  const [error, setError] = useState(null)
  const [statusMessage, setStatusMessage] = useState('Preparing your assessment in the background...')

  const pollRef = useRef(null)

  const apiBase = useMemo(() => import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080', [])

  const clearPoll = () => {
    if (pollRef.current) {
      clearInterval(pollRef.current)
      pollRef.current = null
    }
  }

  const checkReadiness = async () => {
    if (!sessionId) return
    try {
      const statusData = await getSessionStatus(sessionId)

      if (statusData.status === 'READY') {
        const questions = await getSessionQuestions(sessionId)
        if (questions && questions.length >= EXPECTED_QUESTION_COUNT) {
          setQuestionsReady(true)
          setIsPreparing(false)
          setStatusMessage('Questions are ready. You may begin when ready.')
          clearPoll()
          return
        } else {
          setStatusMessage(`Generating questions... (${questions?.length || 0}/${EXPECTED_QUESTION_COUNT})`)
        }
      } else {
        setStatusMessage('Preparing your assessment in the background...')
      }
    } catch (err) {
      console.error('Preparation error:', err)
      setError(err instanceof Error ? err.message : 'Failed to prepare assessment')
      setIsPreparing(false)
      clearPoll()
    }
  }

  useEffect(() => {
    if (!sessionId) return
    setIsPreparing(true)
    setError(null)
    checkReadiness()
    pollRef.current = setInterval(checkReadiness, POLL_INTERVAL_MS)
    return () => clearPoll()
  }, [sessionId])

  const handleBegin = () => {
    navigate(`/psychometric/assessment/${sessionId}`)
  }

  return (
    <div className="page">
      <header className="page__header">
        <div>
          <p className="eyebrow">Psychometric Assessment</p>
          <h1>Test Instructions & Rules</h1>
          <p className="muted">
            Session ID: <strong>{sessionId}</strong>
          </p>
        </div>
        <div className="muted">Backend: {apiBase}</div>
      </header>

      {error && (
        <div className="card">
          <p className="error">{error}</p>
          <button className="btn-primary" onClick={checkReadiness}>
            Retry
          </button>
        </div>
      )}

      {!error && (
        <main className="card instructions">
          <div className="instructions-header">
            <div>
              <h2>Exam Overview</h2>
              <p className="muted">
                Please read all rules before you begin. Questions are preparing in the background.
              </p>
            </div>
            <div className="prep-indicator">
              <div className={`dot ${questionsReady ? 'dot-ready' : 'dot-loading'}`} />
              <span>{statusMessage}</span>
            </div>
          </div>

          <div className="instructions-grid">
            <section className="instructions-block">
              <h3>Question Types & Navigation</h3>
              <ul>
                <li>150 questions across Aptitude, Behavioral, and Domain sections.</li>
                <li>Use Next/Previous or the question palette to navigate.</li>
                <li>Each option can be marked as Answered or left Not Answered.</li>
                <li>"Mark for Review" lets you flag a question to revisit.</li>
                <li>"Answered & Marked for Review" keeps your answer but flags it.</li>
              </ul>
            </section>

            <section className="instructions-block">
              <h3>Time Limit</h3>
              <ul>
                <li>Total time: 1 hour for the entire test.</li>
                <li>Timer starts when you begin the test.</li>
                <li>Test auto-submits when the timer reaches zero.</li>
              </ul>
            </section>

            <section className="instructions-block">
              <h3>Answering Rules</h3>
              <ul>
                <li>You may change answers anytime before submission or timeout.</li>
                <li>Use "Clear Response" to remove a selected answer.</li>
                <li>"Mark for Review" does not count as answered unless an option is selected.</li>
              </ul>
            </section>

            <section className="instructions-block warning">
              <h3>Proctoring Rules</h3>
              <ul>
                <li>Webcam must stay on and your face visible.</li>
                <li>No tab switching or minimizing the window.</li>
                <li>No second face or people in view.</li>
                <li>Do not look away for extended periods.</li>
                <li>Any webcam failure or stream interruption counts as a violation.</li>
                <li>5 violations trigger automatic test submission.</li>
              </ul>
            </section>

            <section className="instructions-block">
              <h3>User Responsibilities</h3>
              <ul>
                <li>Maintain a stable internet connection and power.</li>
                <li>Do not close the browser until submission completes.</li>
                <li>Ensure a quiet environment and avoid distractions.</li>
              </ul>
            </section>
          </div>

          <div className="instructions-actions">
            <button
              className="btn-primary"
              onClick={handleBegin}
              disabled={!questionsReady}
            >
              {questionsReady ? 'Begin Test' : 'Preparing questions…'}
            </button>
          </div>
        </main>
      )}
    </div>
  )
}

export default PsychometricInstructions

