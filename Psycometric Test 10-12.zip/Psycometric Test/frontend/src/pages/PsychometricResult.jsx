import { useEffect, useState } from 'react'
import { useParams, useNavigate, useLocation } from 'react-router-dom'
import { getPsychometricSession } from '../api/psychometric'

function PsychometricResult() {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const [results, setResults] = useState(location.state?.results || null)
  const [session, setSession] = useState(null)
  const [isLoading, setIsLoading] = useState(!results)

  useEffect(() => {
    if (sessionId) {
      loadSession()
    }
  }, [sessionId])

  const loadSession = async () => {
    try {
      const sessionData = await getPsychometricSession(sessionId)
      setSession(sessionData)
    } catch (error) {
      console.error('Failed to load session:', error)
    }
  }

  if (isLoading && !results) {
    return (
      <div className="page">
        <div className="card">
          <p>Loading results...</p>
        </div>
      </div>
    )
  }

  if (!results) {
    return (
      <div className="page">
        <div className="card">
          <p className="error">No results found</p>
          <button onClick={() => navigate('/psychometric/start')}>Go Back</button>
        </div>
      </div>
    )
  }

  const accuracy = results.attempted > 0 
    ? ((results.correct / results.attempted) * 100).toFixed(1) 
    : 0

  const submittedDate = results.submittedAt 
    ? new Date(results.submittedAt).toLocaleString() 
    : 'N/A'

  return (
    <div className="page">
      <header className="page__header">
        <div>
          <p className="eyebrow">Test Results</p>
          <h1>Assessment Complete</h1>
          <p className="muted">
            Session ID: <strong>{sessionId}</strong>
          </p>
          {session?.userInfo && (
            <p className="muted">
              Candidate: <strong>{session.userInfo.name}</strong>
            </p>
          )}
        </div>
      </header>

      <main className="card">
        <div className="results-container">
          <div className="results-header">
            <h2>Test Summary</h2>
            <p className="muted">Submitted on: {submittedDate}</p>
          </div>

          <div className="results-grid">
            <div className="result-card">
              <div className="result-label">Total Questions</div>
              <div className="result-value">{results.totalQuestions}</div>
            </div>

            <div className="result-card">
              <div className="result-label">Attempted</div>
              <div className="result-value success">{results.attempted}</div>
            </div>

            <div className="result-card">
              <div className="result-label">Not Attempted</div>
              <div className="result-value warning">{results.notAttempted}</div>
            </div>

            <div className="result-card">
              <div className="result-label">Correct Answers</div>
              <div className="result-value success">{results.correct}</div>
            </div>

            <div className="result-card">
              <div className="result-label">Wrong Answers</div>
              <div className="result-value error">{results.wrong}</div>
            </div>

            <div className="result-card">
              <div className="result-label">Accuracy</div>
              <div className="result-value">{accuracy}%</div>
            </div>

            <div className="result-card">
              <div className="result-label">Marked for Review</div>
              <div className="result-value info">{results.markedForReview}</div>
            </div>

            <div className="result-card">
              <div className="result-label">Answered & Marked</div>
              <div className="result-value info">{results.answeredAndMarkedForReview}</div>
            </div>
          </div>

          <div className="results-actions">
            <button 
              onClick={() => navigate('/psychometric/start')}
              className="btn-primary"
            >
              Start New Assessment
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}

export default PsychometricResult

