import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { createPsychometricSession } from '../api/psychometric'

const degreeOptions = ['B.Tech', 'BBA', 'B.Com', 'MBA', 'Other']

const initialForm = {
  name: '',
  email: '',
  phone: '',
  age: '',
  degree: 'B.Tech',
  specialization: '',
  careerInterest: '',
}

function PsychometricStart() {
  const navigate = useNavigate()
  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState(null)

  const apiBase = useMemo(() => import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080', [])

  const validate = (data) => {
    const nextErrors = {}
    if (!data.name.trim()) nextErrors.name = 'Name is required'
    if (!data.email.match(/^[^@\s]+@[^@\s]+\.[^@\s]+$/)) nextErrors.email = 'Enter a valid email'
    if (!data.phone || data.phone.length < 7 || data.phone.length > 15)
      nextErrors.phone = 'Phone must be 7-15 digits'
    if (!data.age || Number(data.age) <= 0) nextErrors.age = 'Age is required'
    if (!data.degree) nextErrors.degree = 'Degree is required'
    if (!data.specialization.trim()) nextErrors.specialization = 'Specialization is required'
    if (!data.careerInterest.trim()) nextErrors.careerInterest = 'Career interest is required'
    return nextErrors
  }

  const onSubmit = async (event) => {
    event.preventDefault()
    setSubmitError(null)

    const validation = validate(form)
    setErrors(validation)
    if (Object.keys(validation).length > 0) return

    setIsSubmitting(true)
    try {
      const result = await createPsychometricSession({
        ...form,
        age: Number(form.age),
      })
      // Navigate directly to instructions while questions generate in background
      navigate(`/psychometric/instructions/${result.sessionId}`)
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'Unable to start session')
      setIsSubmitting(false)
    }
  }

  return (
    <div className="page">
      <header className="page__header">
        <div>
          <p className="eyebrow">Psychometric Assessment</p>
          <h1>Start your guided evaluation</h1>
          <p className="muted">
            Fill in your details to generate a tailored 3-section, 150-question assessment. Questions and the final report
            are crafted dynamically with OpenAI.
          </p>
          <div className="pill">
            Backend API base: <span>{apiBase}</span>
          </div>
        </div>
      </header>

      <main className="card">
        <form className="form" onSubmit={onSubmit} noValidate>
          <div className="form__grid">
            <div className="form__field">
              <label htmlFor="name">Full name</label>
              <input
                id="name"
                name="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Enter your full name"
              />
              {errors.name && <p className="error">{errors.name}</p>}
            </div>

            <div className="form__field">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@example.com"
              />
              {errors.email && <p className="error">{errors.email}</p>}
            </div>

            <div className="form__field">
              <label htmlFor="phone">Phone</label>
              <input
                id="phone"
                name="phone"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="Include country code if applicable"
              />
              {errors.phone && <p className="error">{errors.phone}</p>}
            </div>

            <div className="form__field">
              <label htmlFor="age">Age</label>
              <input
                id="age"
                name="age"
                type="number"
                min={15}
                max={80}
                value={form.age}
                onChange={(e) => setForm({ ...form, age: e.target.value === '' ? '' : Number(e.target.value) })}
                placeholder="20"
              />
              {errors.age && <p className="error">{errors.age}</p>}
            </div>

            <div className="form__field">
              <label htmlFor="degree">Degree</label>
              <select
                id="degree"
                name="degree"
                value={form.degree}
                onChange={(e) => setForm({ ...form, degree: e.target.value })}
              >
                {degreeOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              {errors.degree && <p className="error">{errors.degree}</p>}
            </div>

            <div className="form__field">
              <label htmlFor="specialization">Specialization</label>
              <input
                id="specialization"
                name="specialization"
                value={form.specialization}
                onChange={(e) => setForm({ ...form, specialization: e.target.value })}
                placeholder="e.g., CSE, IT, Finance, Marketing"
              />
              {errors.specialization && <p className="error">{errors.specialization}</p>}
            </div>

            <div className="form__field span-2">
              <label htmlFor="careerInterest">Career interest</label>
              <input
                id="careerInterest"
                name="careerInterest"
                value={form.careerInterest}
                onChange={(e) => setForm({ ...form, careerInterest: e.target.value })}
                placeholder="e.g., Software Engineer, Data Analyst, Product Manager"
              />
              {errors.careerInterest && <p className="error">{errors.careerInterest}</p>}
            </div>
          </div>

          <div className="actions">
            <button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Creating session…' : 'Start assessment'}
            </button>
            {submitError && <p className="error">{submitError}</p>}
          </div>
        </form>
      </main>
    </div>
  )
}

export default PsychometricStart

